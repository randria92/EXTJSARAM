Ext.define("Chapter10.model.Country",{
	extend : "Ext.data.Model",
	fields : ["name","capital","continent"]
});