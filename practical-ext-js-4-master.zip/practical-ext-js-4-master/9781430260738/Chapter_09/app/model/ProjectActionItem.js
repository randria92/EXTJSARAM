﻿Ext.define("Chapter09.model.ProjectActionItem", {
    extend : "Ext.data.Model",
    fields : ["sno","item","officer","status","createdby","createddate"]
});